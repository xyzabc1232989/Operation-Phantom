; PASSWORD_CHECKER.ASM
; Full words version - prints complete words for better readability

.MODEL SMALL
.STACK 256
.DATA
    ; Input/Output strings
    prompt      DB 'PASSWORD: $'
    result_msg  DB 'RESULT: $'
    newline     DB 0DH,0AH,'$'
    
    ; Buffer for password input
    buffer      DB 50, 0, 50 DUP('$')
    
    ; Analysis variables
    len_word    DW 0
    upper_flag  DB 0
    lower_flag  DB 0
    digit_flag  DB 0
    special_flag DB 0
    total_score DW 0
    
    ; Full crack time strings
    time_years  DB 'YEARS$'
    time_months DB 'MONTHS$'
    time_days   DB 'DAYS$'
    time_hours  DB 'HOURS$'
    time_mins   DB 'MINUTES$'
    
    ; Full weakness strings
    wk_len      DB 'TOO SHORT$'
    wk_upper    DB 'NO UPPERCASE$'
    wk_lower    DB 'NO LOWERCASE$'
    wk_digit    DB 'NO NUMBERS$'
    wk_special  DB 'NO SPECIAL CHARS$'
    wk_none     DB 'NONE$'

.CODE
START:
    MOV AX, @DATA
    MOV DS, AX
    
    ; Print prompt
    LEA DX, prompt
    MOV AH, 09H
    INT 21H
    
    ; Read password input
    LEA DX, buffer
    MOV AH, 0AH
    INT 21H
    
    ; Print newline
    LEA DX, newline
    MOV AH, 09H
    INT 21H
    
    ; Get password length
    XOR AX, AX
    MOV AL, buffer+1
    MOV len_word, AX
    
    ; Check if password is empty
    CMP len_word, 0
    JE EXIT_PROGRAM
    
    ; Analyze password character by character
    LEA SI, buffer+2
    XOR CX, CX
    MOV CX, len_word
    
    ANALYZE_CHARS:
        MOV AL, [SI]
        
        ; Check uppercase A-Z
        CMP AL, 'A'
        JB CHECK_LOWER_CASE
        CMP AL, 'Z'
        JA CHECK_LOWER_CASE
        MOV upper_flag, 1
        JMP NEXT_CHARACTER
        
        CHECK_LOWER_CASE:
        ; Check lowercase a-z
        CMP AL, 'a'
        JB CHECK_DIGIT_CASE
        CMP AL, 'z'
        JA CHECK_DIGIT_CASE
        MOV lower_flag, 1
        JMP NEXT_CHARACTER
        
        CHECK_DIGIT_CASE:
        ; Check digit 0-9
        CMP AL, '0'
        JB CHECK_SPECIAL_CASE
        CMP AL, '9'
        JA CHECK_SPECIAL_CASE
        MOV digit_flag, 1
        JMP NEXT_CHARACTER
        
        CHECK_SPECIAL_CASE:
        ; Anything else is special character
        MOV special_flag, 1
        
        NEXT_CHARACTER:
        INC SI
        LOOP ANALYZE_CHARS
    
    ; Calculate score
    CALL CALCULATE_TOTAL_SCORE
    
    ; Print result header
    LEA DX, result_msg
    MOV AH, 09H
    INT 21H
    
    ; Print score
    MOV AX, total_score
    CALL PRINT_NUMBER
    
    ; Print separator
    MOV DL, '|'
    MOV AH, 02H
    INT 21H
    
    ; Print crack time (full word)
    CALL PRINT_CRACK_TIME
    
    ; Print separator
    MOV DL, '|'
    MOV AH, 02H
    INT 21H
    
    ; Print weaknesses (full words, comma separated)
    CALL PRINT_WEAKNESSES
    
    ; Print newline at the end
    LEA DX, newline
    MOV AH, 09H
    INT 21H
    
    EXIT_PROGRAM:
    MOV AH, 4CH
    INT 21H

; ============================================
; Calculate total score (0-100)
; ============================================
CALCULATE_TOTAL_SCORE PROC
    MOV total_score, 0
    
    ; Length score (max 35)
    MOV AX, len_word
    CMP AX, 12
    JGE LEN_35
    CMP AX, 10
    JGE LEN_30
    CMP AX, 8
    JGE LEN_25
    CMP AX, 6
    JGE LEN_20
    CMP AX, 4
    JGE LEN_15
    JMP ADD_LEN_10
    
    LEN_35:
        ADD total_score, 35
        JMP ADD_UPPER
    LEN_30:
        ADD total_score, 30
        JMP ADD_UPPER
    LEN_25:
        ADD total_score, 25
        JMP ADD_UPPER
    LEN_20:
        ADD total_score, 20
        JMP ADD_UPPER
    LEN_15:
        ADD total_score, 15
        JMP ADD_UPPER
    ADD_LEN_10:
        ADD total_score, 10
    
    ADD_UPPER:
    CMP upper_flag, 1
    JNE ADD_LOWER
    ADD total_score, 20
    
    ADD_LOWER:
    CMP lower_flag, 1
    JNE ADD_DIGIT
    ADD total_score, 20
    
    ADD_DIGIT:
    CMP digit_flag, 1
    JNE ADD_SPECIAL
    ADD total_score, 15
    
    ADD_SPECIAL:
    CMP special_flag, 1
    JNE FINISH_SCORE
    ADD total_score, 10
    
    FINISH_SCORE:
    CMP total_score, 100
    JLE SCORE_OK
    MOV total_score, 100
    
    SCORE_OK:
    RET
CALCULATE_TOTAL_SCORE ENDP

; ============================================
; Print crack time (full word)
; ============================================
PRINT_CRACK_TIME PROC
    MOV AX, total_score
    CMP AX, 80
    JGE SHOW_YEARS
    CMP AX, 60
    JGE SHOW_MONTHS
    CMP AX, 40
    JGE SHOW_DAYS
    CMP AX, 20
    JGE SHOW_HOURS
    
    SHOW_MINS:
        LEA DX, time_mins
        JMP SHOW_TIME
    SHOW_HOURS:
        LEA DX, time_hours
        JMP SHOW_TIME
    SHOW_DAYS:
        LEA DX, time_days
        JMP SHOW_TIME
    SHOW_MONTHS:
        LEA DX, time_months
        JMP SHOW_TIME
    SHOW_YEARS:
        LEA DX, time_years
    
    SHOW_TIME:
        MOV AH, 09H
        INT 21H
        RET
PRINT_CRACK_TIME ENDP

; ============================================
; Print weaknesses (full words, comma separated)
; ============================================
PRINT_WEAKNESSES PROC
    MOV CX, 0  ; Counter for printed weaknesses
    
    ; Check length weakness
    CMP len_word, 8
    JGE CHECK_UPPER_WEAK
    LEA DX, wk_len
    MOV AH, 09H
    INT 21H
    INC CX
    
    CHECK_UPPER_WEAK:
    CMP upper_flag, 1
    JE CHECK_LOWER_WEAK
    CMP CX, 0
    JE NO_COMMA1
    MOV DL, ','
    MOV AH, 02H
    INT 21H
    MOV DL, ' '
    INT 21H
    NO_COMMA1:
    LEA DX, wk_upper
    MOV AH, 09H
    INT 21H
    INC CX
    
    CHECK_LOWER_WEAK:
    CMP lower_flag, 1
    JE CHECK_DIGIT_WEAK
    CMP CX, 0
    JE NO_COMMA2
    MOV DL, ','
    MOV AH, 02H
    INT 21H
    MOV DL, ' '
    INT 21H
    NO_COMMA2:
    LEA DX, wk_lower
    MOV AH, 09H
    INT 21H
    INC CX
    
    CHECK_DIGIT_WEAK:
    CMP digit_flag, 1
    JE CHECK_SPECIAL_WEAK
    CMP CX, 0
    JE NO_COMMA3
    MOV DL, ','
    MOV AH, 02H
    INT 21H
    MOV DL, ' '
    INT 21H
    NO_COMMA3:
    LEA DX, wk_digit
    MOV AH, 09H
    INT 21H
    INC CX
    
    CHECK_SPECIAL_WEAK:
    CMP special_flag, 1
    JE WEAK_DONE
    CMP CX, 0
    JE NO_COMMA4
    MOV DL, ','
    MOV AH, 02H
    INT 21H
    MOV DL, ' '
    INT 21H
    NO_COMMA4:
    LEA DX, wk_special
    MOV AH, 09H
    INT 21H
    INC CX
    
    WEAK_DONE:
    CMP CX, 0
    JNE NO_WEAK_MSG
    LEA DX, wk_none
    MOV AH, 09H
    INT 21H
    
    NO_WEAK_MSG:
    RET
PRINT_WEAKNESSES ENDP

; ============================================
; Print number in AX
; ============================================
PRINT_NUMBER PROC
    PUSH AX
    PUSH BX
    PUSH CX
    PUSH DX
    
    XOR CX, CX
    MOV BX, 10
    
    DIVIDE_LOOP:
        XOR DX, DX
        DIV BX
        PUSH DX
        INC CX
        CMP AX, 0
        JNE DIVIDE_LOOP
    
    PRINT_DIGIT_LOOP:
        POP DX
        ADD DL, '0'
        MOV AH, 02H
        INT 21H
        LOOP PRINT_DIGIT_LOOP
    
    POP DX
    POP CX
    POP BX
    POP AX
    RET
PRINT_NUMBER ENDP

END START